# app/etl/tasks/transform.py

from app.etl.celery_app import celery_app
from app.adapters.generic_erp import GenericJSONAdapter
from app.db.session import SessionLocal
from app.db.models import ETLJob, ETLRowError, ETLJobStatus
import logging
import pydantic

log = logging.getLogger(__name__)
adapter = GenericJSONAdapter()

CHUNK_SIZE = 50   # process 50 rows per Celery task — keeps memory low


@celery_app.task(bind=True, name="app.etl.tasks.transform.transform_batch", max_retries=3)
def transform_batch(self, job_id: str, raw_rows: list, tenant_id: str = "anonymous"):
    """
    Stage 2: Transform — adapter normalises raw rows to InvoicePayload.
    Splits into chunks and fans out to validate tasks.
    """
    db = SessionLocal()
    try:
        valid_invoices = []
        row_errors = []

        for i, row in enumerate(raw_rows):
            try:
                invoice = adapter.transform(row)
                valid_invoices.append((i + 1, invoice, row))
            except pydantic.ValidationError as e:
                row_errors.append(ETLRowError(
                    etl_job_id=job_id,
                    row_number=i + 1,
                    invoice_number=row.get("invoice_number", "Unknown"),
                    error_type="SCHEMA",
                    error_message=str(e),
                    raw_data=row,
                ))
            except Exception as e:
                row_errors.append(ETLRowError(
                    etl_job_id=job_id,
                    row_number=i + 1,
                    invoice_number=row.get("invoice_number", "Unknown"),
                    error_type="PARSE",
                    error_message=str(e),
                    raw_data=row,
                ))

        if row_errors:
            db.bulk_save_objects(row_errors)
            db.commit()

        log.info(f"ETL Transform: job={job_id}, valid={len(valid_invoices)}, errors={len(row_errors)}")

        # Fan out validation in chunks
        chunks = [valid_invoices[i:i+CHUNK_SIZE] for i in range(0, len(valid_invoices), CHUNK_SIZE)]
        from app.etl.tasks.validate import validate_chunk

        for chunk_idx, chunk in enumerate(chunks):
            # Serialize invoice objects to dict for Celery (can't pass Pydantic objects)
            serialized = [
                (row_num, invoice.model_dump(), raw)
                for row_num, invoice, raw in chunk
            ]
            validate_chunk.delay(job_id, chunk_idx, serialized, len(raw_rows), len(row_errors), tenant_id=tenant_id)

        if not valid_invoices:
            # All rows failed transform — mark job done
            from app.db.session import SessionLocal as SL
            db2 = SL()
            job = db2.query(ETLJob).filter(ETLJob.id == job_id).first()
            if job:
                job.status = ETLJobStatus.PARTIAL.value
                job.failed_rows = len(row_errors)
                db2.commit()
            db2.close()

        return {"job_id": job_id, "transformed": len(valid_invoices), "failed": len(row_errors)}

    except Exception as exc:
        log.error(f"ETL Transform failed: job={job_id}, error={exc}")
        raise self.retry(exc=exc, countdown=5)
    finally:
        db.close()
